<div class="modal-footer">
    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
    <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
</div>
<?php /**PATH C:\laragon\www\Klinik\resources\views/perawat/modalPerawat/partials/footer-pasien.blade.php ENDPATH**/ ?>