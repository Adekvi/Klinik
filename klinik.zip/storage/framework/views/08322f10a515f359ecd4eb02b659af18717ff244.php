<?php if(Request::is('/')): ?>
    <footer id="footer" class="footer">

        <div class="text-center position-relative">
            <div class="container">
                <div class="copyright">
                    &copy; Copyright <strong><span>Klinik<span style="color: orange;"></span></span></strong>. All Rights
                    Reserved
                    <h6>Klinik Pratama Multisari II - <?= date('Y') ?></h6>
                </div>
            </div>
        </div>

    </footer>
<?php endif; ?>
<?php /**PATH C:\laragon\www\Klinik\resources\views/components/user/footer.blade.php ENDPATH**/ ?>